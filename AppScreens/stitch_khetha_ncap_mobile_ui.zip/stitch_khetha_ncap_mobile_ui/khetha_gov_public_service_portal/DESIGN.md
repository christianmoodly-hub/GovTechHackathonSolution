---
name: Khetha Gov Public Service Portal
colors:
  surface: '#f9f9ff'
  surface-dim: '#cfdaf2'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#dee8ff'
  surface-container-highest: '#d8e3fb'
  on-surface: '#111c2d'
  on-surface-variant: '#3f4944'
  inverse-surface: '#263143'
  inverse-on-surface: '#ecf1ff'
  outline: '#6f7a73'
  outline-variant: '#bec9c2'
  surface-tint: '#046c50'
  primary: '#00503a'
  on-primary: '#ffffff'
  primary-container: '#006a4e'
  on-primary-container: '#92e7c3'
  inverse-primary: '#83d7b4'
  secondary: '#1960a3'
  on-secondary: '#ffffff'
  secondary-container: '#7db6ff'
  on-secondary-container: '#00477f'
  tertiary: '#5c4000'
  on-tertiary: '#ffffff'
  tertiary-container: '#7a5600'
  on-tertiary-container: '#ffce77'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#9ef4d0'
  primary-fixed-dim: '#83d7b4'
  on-primary-fixed: '#002116'
  on-primary-fixed-variant: '#00513b'
  secondary-fixed: '#d3e4ff'
  secondary-fixed-dim: '#a2c9ff'
  on-secondary-fixed: '#001c38'
  on-secondary-fixed-variant: '#004881'
  tertiary-fixed: '#ffdea8'
  tertiary-fixed-dim: '#fbbc38'
  on-tertiary-fixed: '#271900'
  on-tertiary-fixed-variant: '#5e4200'
  background: '#f9f9ff'
  on-background: '#111c2d'
  surface-variant: '#d8e3fb'
  gov-green-dark: '#08503C'
  gov-green-light: '#E6F4EA'
  dhet-gold: '#F2A900'
  dhet-gold-hover: '#D9822B'
  khetha-blue: '#2563EB'
  khetha-blue-subtle: '#EFF6FF'
  warm-ochre: '#C2611A'
  surface-canvas: '#F8FAFC'
  surface-card: '#FFFFFF'
  surface-muted: '#F1F5F9'
  border-subtle: '#E2E8F0'
  border-strong: '#CBD5E1'
  text-primary: '#0F172A'
  text-secondary: '#475569'
  state-success: '#15803D'
  state-warning: '#B45309'
  state-info: '#1D4ED8'
  state-accent: '#6D28D9'
typography:
  display:
    fontFamily: Public Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg:
    fontFamily: Public Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
  headline-lg-mobile:
    fontFamily: Public Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 30px
  headline-md:
    fontFamily: Public Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Public Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Public Sans
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Public Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Public Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Public Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Public Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  caption:
    fontFamily: Public Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The brand personality represents the intersection of state authority, civic reliability, and inspiring personal empowerment. Built for the Department of Higher Education and Training (DHET) and the Khetha Career Guidance initiative, the system serves a wide citizen base across South Africa—from rural school leavers and TVET students to career practitioners and individuals living with disabilities. The emotional tone is authoritative yet approachable, transparent, uplifting, and unconditionally inclusive.

The design movement adopted is **Corporate / Modern Accessibility-First**. It emphasizes high legibility, strict contrast boundaries, distinct visual affordances, and clean spatial rhythm. Rather than fragile aesthetic trends, this interface provides resilient clarity across diverse mobile viewports, low-bandwidth connections, high ambient sunlight, and dynamic multilingual translation where copy strings expand significantly.

## Colors

The color architecture is anchored in the official national colors of the Republic of South Africa and the DHET identity:
- **Primary (`#006A4E`)**: Deep Forest Green establishes institutional legitimacy, security, and pride. Used for primary navigation headers, main call-to-action buttons, and core brand anchors.
- **Secondary (`#2B6CB0`)**: Khetha Education Slate Blue provides a calm, scholarly tone ideal for informational banners, interactive questionnaire pathways, and contextual links.
- **Tertiary (`#E5A823`)**: DHET Gold adds energetic guidance cues, active status indicators, and focus rings.
- **Neutrals**: Crisp pure white (`#FFFFFF`) cards sit on an ultra-light slate backdrop (`#F8FAFC`), paired with deep slate text (`#0F172A` / `#1E293B`) to ensure WCAG AAA compliance for maximum legibility in outdoor sunlight.

All functional states (success, warning, error, info) follow high-contrast hues designed to be distinguishable without relying on color perception alone.

## Typography

Typography uses **Public Sans**, an open-source, highly legible grotesque typeface designed specifically for civic and institutional clarity across screens of varying pixel densities.

### Multilingual Resilience & Translation
South Africa recognizes 12 official languages. Texts in isiZulu, Sesotho, Setswana, and Afrikaans frequently experience horizontal expansion between 25% and 40% compared to English. Therefore:
- Strict character line wrapping is enabled with auto-hyphenation where appropriate.
- Headings avoid hardcoded component widths, using flexible vertical stacks instead.
- Generous line heights (`1.5` to `1.6` ratio on body copy) accommodate diacritics and prevent visual clutter on mobile viewports.
- All labels and primary actions feature a minimum target baseline of 14px to prevent eye strain.

## Layout & Spacing

The layout philosophy is based on a **mobile-first fluid grid** with a maximum container restriction of 1200px on desktop and a compact single-column flow on mobile viewports.

### Responsive Breakpoints & Adaptive Margins
- **Mobile (< 640px):** Single-column stacked layout with 16px (`1rem`) outer margins and 12px (`0.75rem`) gutters. All interactive touch elements conform to the minimum 48px hit dimension.
- **Tablet (640px - 1024px):** 6-column fluid structure with 24px (`1.5rem`) margins.
- **Desktop (> 1024px):** 12-column grid layout with centered containment and 32px margins.

### Spacing Model
A modular 4px/8px incremental rhythm is enforced. Component padding uses `space-md` (16px) internally for standard cards and form groups, collapsing to `space-sm` (8px) for compact listing modules.

## Elevation & Depth

Visual hierarchy employs a **hybrid approach: structural low-contrast borders combined with soft, low-blur ambient shadows**. This prevents muddy gradients on budget display hardware while preserving tactile affordances for citizens of varying digital literacy.

- **Level 0 (Base Canvas):** Flat surface background tinted with `#F8FAFC`.
- **Level 1 (Card & Content Blocks):** Solid `#FFFFFF` background with a crisp 1px border (`#E2E8F0`) and a subtle ambient drop shadow: `0 1px 3px rgba(15, 23, 42, 0.06), 0 1px 2px rgba(15, 23, 42, 0.04)`.
- **Level 2 (Interactive Floating Elements, Flyouts, Active Filters):** 1px border (`#CBD5E1`) with `0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Modals, Demographic Questionnaires, Dialog Overlays):** Semi-opaque tinted scrim (`rgba(15, 23, 42, 0.65)`) with a central white card carrying an elevated shadow `0 20px 25px -5px rgba(15, 23, 42, 0.15)`.

## Shapes

The design system maintains a **Soft (`1`)** roundedness scale. Rounded corners are intentional, practical, and restrained:
- Base inputs, buttons, and demographic selectors use `0.25rem` (4px) or `0.375rem` (6px) corner radius to retain an institutional, dependable identity.
- Cards, dialogue overlays, and banners use `0.5rem` (8px) corner radius.
- Status badges and filter pills utilize full pill contours (`9999px`) to create clear differentiation between interactive pills and structured square-cornered informational cards.

## Components

### Buttons
- **Primary:** Background in Deep Forest Green (`#006A4E`), text in `#FFFFFF`, with 48px minimum height. Active state transitions to `#08503C`.
- **Secondary:** Outlined with a 2px solid `#006A4E` or `#2B6CB0` border, transparent background, and `#006A4E` text.
- **Tertiary / Action (DHET Gold):** `#F2A900` background with high-contrast `#0F172A` text, designated for application completions and prominent step validations.

### Questionnaire & Demographic Selection
- **Segmented Choices (e.g., Disability / Category Selection):** Custom accessible radio tiles with 48px minimum vertical touch target, featuring a 2px outline in `#CBD5E1`, transitioning to `#006A4E` with an inner filled indicator when selected.
- **Select Dropdowns:** 48px height, 1px `#CBD5E1` border, distinct downward chevron glyph, and explicit helper labels positioned permanently above the field.

### Chips & Filter Pills
- **Category Chips:** Light tint background (`#EFF6FF` or `#F1F5F9`) with 1px border (`#CBD5E1`), 36px height, and semi-bold 13px text.
- **Active State:** Background `#006A4E` with white text and an accessible dismiss (`×`) icon.

### Offline / Connectivity Indicators
- Dedicated compact header badge displaying portal sync state: Green dot (`#15803D`) for online and Amber banner (`#B45309`) with a cloud-off icon for offline cached mode.

### Cards & Content Modules
- Pure white surfaces with 16px internal padding, framed by `#E2E8F0` borders. Educational pathway cards feature a 4px left-hand accent bar colored by field (e.g., Green for STEM, Blue for Humanities, Ochre for Artisan/TVET).